const fs = require('fs'); // Módulo para trabajar con el sistema de archivos

// Códigos de escape ANSI para colores
const COLOR_AZUL = '\x1b[34m'; // Azul
const COLOR_ROSA = '\x1b[35m'; // Rosa
const COLOR_RESET = '\x1b[0m'; // Reset para volver al color original

class Pila {
    constructor() {
        this.items = []; // Almacena los elementos de la pila
    }

    // Añade un nuevo elemento a la cima de la pila
    push(element) {
        this.items.push(element);
    }

    // Elimina y retorna el elemento de la cima de la pila
    pop() {
        return this.items.pop();
    }

    // Retorna el elemento de la cima de la pila sin eliminarlo
    peek() {
        return this.items[this.items.length - 1];
    }

    // Verifica si la pila está vacía
    isEmpty() {
        return this.items.length === 0;
    }

    // Retorna el número de elementos en la pila
    size() {
        return this.items.length;
    }

    // Vacía todos los elementos de la pila
    clear() {
        this.items = [];
    }
}

class MaquinaVirtualSimple {
    constructor() {
        this.instrucciones = []; // Almacena las instrucciones del programa
        this.instructionPointer = 0; // Apuntador a la instrucción actual
        this.tablero = Array(10).fill().map(() => Array(10).fill('~')); // Inicializa el tablero de 10x10 con '~'
        this.sprites = {}; // Almacena los barcos creados
        this.barcosHundidos = 0; // Lleva el conteo de los barcos hundidos
        this.pilaBarcos = new Pila(); // Pila que contiene los barcos
    }

    // Carga un programa desde un archivo
    cargarProgramaDesdeArchivo(archivo) {
        try {
            const data = fs.readFileSync(archivo, 'utf8'); // Lee el archivo
            this.instrucciones = data.split('\n').map(line => line.trim()).filter(line => line.length > 0); // Procesa las instrucciones
        } catch (error) {
            console.error("Error al leer el archivo:", error); // Muestra un error si ocurre
        }
    }

    // Ejecuta las instrucciones del programa cargado
    ejecutar() {
        this.procesarInstrucciones(); // Procesa cada instrucción en la lista
    }

    // Procesa cada instrucción
    procesarInstrucciones() {
        while (this.instructionPointer < this.instrucciones.length) {
            const instruccion = this.instrucciones[this.instructionPointer].split(' '); // Divide la instrucción en partes
            const comando = instruccion[0]; // Obtiene el comando

            // Procesa el comando correspondiente
            if (comando === 'PUSH') {
                this.procesarBarco(instruccion); // Procesa la creación de un barco
            } else if (comando === 'DRAW' || comando === 'IMPRIMIR') {
                this.imprimirTablero(); // Imprime el tablero
            } else if (comando === 'HALT') {
                break; // Detiene la ejecución del programa
            } else {
                break; // Detiene la ejecución en caso de un comando desconocido
            }
            this.instructionPointer++; // Avanza al siguiente comando
        }
    }

    // Procesa la instrucción PUSH para crear un barco
    procesarBarco(instruccion) {
        const x = parseInt(instruccion[1]); // Coordenada x
        const y = parseInt(instruccion[2]); // Coordenada y
        const direccion = instruccion[3]; // Dirección (horizontal o vertical)
        const tamaño = parseInt(instruccion[4]); // Tamaño del barco
        const nombre = `barco_${x}_${y}`; // Nombre del barco basado en las coordenadas

        const posiciones = this.crearBarco(x, y, tamaño, direccion); // Crea las posiciones del barco
        if (posiciones.length > 0) { // Solo almacena barcos válidos
            this.sprites[nombre] = posiciones; // Almacena el barco en el objeto sprites
            this.pilaBarcos.push({ nombre, posiciones }); // Añade el barco a la pila
        }
    }

    // Crea un barco en las posiciones especificadas
    crearBarco(x, y, tamaño, direccion) {
        const posiciones = []; // Almacena las posiciones del barco
        for (let i = 0; i < tamaño; i++) {
            if (direccion === 'horizontal') {
                if (x + i < 10) {
                    posiciones.push([x + i, y]); // Añade una posición horizontal
                } else {
                    return []; // Si excede el tablero, devuelve un array vacío
                }
            } else if (direccion === 'vertical') {
                if (y + i < 10) {
                    posiciones.push([x, y + i]); // Añade una posición vertical
                } else {
                    return []; // Si excede el tablero, devuelve un array vacío
                }
            }
        }
        return posiciones; // Retorna las posiciones del barco
    }

    // Procesa el disparo a las coordenadas (x, y)
    disparar(x, y) {
        if (x < 0 || x >= 10 || y < 0 || y >= 10) {
            console.log(`Coordenadas fuera del rango: (${x}, ${y}).`); // Verifica si las coordenadas están dentro del tablero
            return false;
        }

        let acierto = false;
        const pilaTemporal = new Pila(); // Pila temporal para almacenar barcos temporalmente

        while (!this.pilaBarcos.isEmpty()) {
            const { nombre, posiciones } = this.pilaBarcos.pop(); // Saca un barco de la pila

            let barcoGolpeado = false;

            for (let j = 0; j < posiciones.length; j++) {
                const [posX, posY] = posiciones[j];
                if (posX === x && posY === y) {
                    this.tablero[y][x] = 'X'; // Marca el acierto en el tablero
                    console.log(`Acierto en (${x}, ${y}) al barco ${nombre}!`);
                    posiciones.splice(j, 1); // Elimina la posición golpeada del barco
                    barcoGolpeado = true;
                    acierto = true;
                    break; // Sale del bucle tras un acierto
                }
            }

            if (posiciones.length > 0) {
                pilaTemporal.push({ nombre, posiciones }); // Si el barco no está completamente hundido, lo vuelve a poner en la pila temporal
            } else if (barcoGolpeado) {
                console.log(`¡Has hundido el ${nombre}!`); // Indica que el barco ha sido hundido
                this.barcosHundidos++;
            }
        }

        while (!pilaTemporal.isEmpty()) {
            this.pilaBarcos.push(pilaTemporal.pop()); // Regresa los barcos no hundidos a la pila original
        }

        if (!acierto) {
            this.tablero[y][x] = 'O'; // Marca el fallo en el tablero
            console.log(`Fallaste en (${x}, ${y}).`);
        }

        return acierto; // Retorna si el disparo fue un acierto
    }

    // Imprime el estado actual del tablero con colores
    imprimirTablero() {
        console.log("Tablero:");
        for (let i = 0; i < 10; i++) {
            const filaColoreada = this.tablero[i].map(celda => {
                if (celda === '~') {
                    return `${COLOR_AZUL}${celda}${COLOR_RESET}`; // Aplica color azul al agua
                } else if (celda === 'X') {
                    return `${COLOR_ROSA}${celda}${COLOR_RESET}`; // Aplica color rosa al acierto
                } else {
                    return celda; // Mantiene el color por defecto
                }
            }).join(' ');
            console.log(filaColoreada); // Imprime cada fila con los colores aplicados
        }
    }

    // Verifica si todos los barcos han sido hundidos
    todosLosBarcosHundidos() {
        return this.barcosHundidos >= Object.keys(this.sprites).length; // Retorna verdadero si todos los barcos han sido hundidos
    }
}

module.exports = MaquinaVirtualSimple; // Exporta la clase MaquinaVirtualSimple para usarla en otros archivos

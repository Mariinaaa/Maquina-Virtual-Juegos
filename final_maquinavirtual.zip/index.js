// Importar módulos y clases
const readline = require('readline'); // Módulo para leer la entrada de la consola
const fs = require('fs'); // Módulo para interactuar con el sistema de archivos
const MaquinaVirtualSimple = require('./MaquinaVirtualSimple'); // Clase de la máquina virtual simple
const TorresDeHanoi = require('./MaquinaVirtualHanoi');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Función para listar archivos .mc en el directorio actual
function listarArchivosMC(callback) {
    fs.readdir('.', (err, archivos) => { // Leer los archivos del directorio actual
        if (err) {
            console.error("Error al leer el directorio:", err); // Mostrar un error si ocurre
            return callback([]); // Retornar un array vacío si hay un error
        }
        const archivosMC = archivos.filter(archivo => archivo.endsWith('.mc')); // Filtrar solo los archivos .mc
        callback(archivosMC); // Retornar los archivos .mc encontrados
    });
}

function jugarTorresDeHanoi() {
    const juegoHanoi = new TorresDeHanoi();
    rl.question("¿Cuántos discos quieres usar? ", (numDiscos) => {
        juegoHanoi.inicializar(parseInt(numDiscos));

        const mostrarEstadoTorres = () => {
            juegoHanoi.mostrarTorres();
        };

        mostrarEstadoTorres();

        const solicitarMovimiento = () => {
            rl.question("Ingresa el movimiento (deTorre aTorre) o 'exit' para salir: ", (input) => {
                if (input.toLowerCase() === 'exit') {
                    console.log("Saliendo del juego de Torres de Hanoi.");
                    rl.close();
                    return;
                }

                const [deTorre, aTorre] = input.split(',').map(Number);

                if (isNaN(deTorre) || isNaN(aTorre) || deTorre < 1 || deTorre > 3 || aTorre < 1 || aTorre > 3) {
                    console.log("Entrada no válida. Debes ingresar números del 1 al 3.");
                    return solicitarMovimiento();
                }

                const movimientoExitoso = juegoHanoi.mover(deTorre - 1, aTorre - 1);
                if (movimientoExitoso) {
                    console.log(`Moviendo disco de la Torre ${deTorre} a la Torre ${aTorre}.`);
                    mostrarEstadoTorres();
                } else {
                    console.log("Movimiento no permitido.");
                }

                if (juegoHanoi.haGanado()) {
                    console.log("¡Felicidades, has ganado!");
                    rl.close();
                } else {
                    solicitarMovimiento();
                }
            });
        };

        solicitarMovimiento();
    });
}

// Función para iniciar el juego Hundir la flota
function iniciarHundirLaFlota() {
    console.log("Iniciando Hundir la flota...");

    const maquina = new MaquinaVirtualSimple(); // Crear una nueva instancia de MaquinaVirtualSimple
    const disparosRealizados = new Set(); // Definir la variable para almacenar disparos realizados

    listarArchivosMC((archivos) => { // Llamar a la función para listar archivos
        if (archivos.length === 0) { // Verificar si no hay archivos .mc
            console.log("No se encontraron archivos .mc. Asegúrate de que haya archivos en el directorio.");
            rl.close(); // Cerrar la interfaz de readline
            return;
        }

        console.log("Selecciona un archivo .mc:");
        archivos.forEach((archivo, index) => { // Listar los archivos disponibles
            console.log(`${index + 1}. ${archivo}`); // Uso de template literals para interpolar variables
        });

        rl.question("Ingresa el número del archivo que deseas cargar: ", (opcion) => { // Preguntar al usuario por el archivo a cargar
            const archivoSeleccionado = archivos[parseInt(opcion) - 1]; // Obtener el archivo seleccionado

            if (!archivoSeleccionado) { // Verificar si la opción ingresada es válida
                console.log("Opción no válida.");
                rl.close(); // Cerrar la interfaz de readline
                return;
            }

            maquina.cargarProgramaDesdeArchivo(archivoSeleccionado); // Cargar el programa desde el archivo .mc

            maquina.ejecutar(); // Ejecutar las instrucciones del programa cargado

            // Función para realizar un disparo en Hundir la flota
            const disparar = () => {
                maquina.imprimirTablero(); // Mostrar el tablero

                rl.question('Ingresa las coordenadas para disparar (x,y) o "exit" para salir: ', (input) => { // Pedir las coordenadas para disparar
                    if (input.toLowerCase() === 'exit') { // Verificar si el usuario desea salir
                        console.log("Saliendo del juego de Hundir la flota.");
                        rl.close(); // Cerrar la interfaz de readline
                        return;
                    }

                    const [x, y] = input.split(',').map(Number); // Parsear las coordenadas

                    // Verificar si las coordenadas están dentro del rango permitido
                    if (x < 0 || x >= 10 || y < 0 || y >= 10) {
                        console.log("Coordenadas fuera del rango. Debes ingresar valores entre 0 y 9.");
                        return disparar(); // Volver a solicitar coordenadas
                    }

                    if (!disparosRealizados.has(`${x},${y}`)) { // Verificar si ya se ha disparado en esas coordenadas
                        disparosRealizados.add(`${x},${y}`); // Agregar las coordenadas a la lista de disparos realizados
                        const resultado = maquina.disparar(x, y); // Realizar el disparo
                        if (resultado) {
                            console.log(`Disparo en (${x}, ${y}) exitoso.`); // Uso de template literals
                        } else {
                            console.log(`Fallaste en (${x}, ${y}).`); // Uso de template literals
                        }

                        if (maquina.todosLosBarcosHundidos()) { // Verificar si el jugador ha hundido todos los barcos
                            console.log("¡Has hundido todos los barcos! Fin del juego.");
                            rl.close(); // Cerrar la interfaz de readline
                        } else {
                            disparar(); // Volver a solicitar un disparo
                        }
                    } else {
                        console.log("Ya disparaste en estas coordenadas. Prueba con otras."); // Informar si ya se disparó en esas coordenadas
                        disparar(); // Solicitar nuevas coordenadas
                    }
                });
            };

            disparar(); // Iniciar la secuencia de disparos
        });
    });
}

function mostrarMenu() {
    console.log("Elige un juego:");
    console.log("1. Torres de Hanoi");
    console.log("2. Hundir la flota");
    console.log("3. Salir");
}

mostrarMenu();
rl.question("Selecciona una opción: ", (opcion) => {
    switch (opcion) {
        case '1':
            jugarTorresDeHanoi();
            break;
        case '2':
            iniciarHundirLaFlota();
            break;
        case '3':
            console.log("Gracias por jugar. ¡Hasta la próxima!");
            rl.close();
            break;
        default:
            console.log("Opción no válida. Por favor selecciona 1 o 2.");
            rl.close();
    }
});

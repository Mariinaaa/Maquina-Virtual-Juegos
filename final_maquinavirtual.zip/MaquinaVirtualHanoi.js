const chalk = require('chalk'); // Importar chalk para usar colores

class Pila {
    constructor() {
        this.items = [];
    }

    push(element) {
        this.items.push(element);
    }

    pop() {
        return this.items.pop();
    }

    peek() {
        return this.items[this.items.length - 1];
    }

    isEmpty() {
        return this.items.length === 0;
    }

    size() {
        return this.items.length;
    }

    clear() {
        this.items = [];
    }
}

class TorresDeHanoi {
    constructor() {
        this.torres = [new Pila(), new Pila(), new Pila()];
    }

    inicializar(numDiscos) {
        for (let i = numDiscos; i > 0; i--) {
            this.torres[0].push(i);
        }
    }

    mover(deTorre, aTorre) {
        if (this.torres[deTorre].isEmpty()) {
            console.log("No hay discos en la torre de origen.");
            return false;
        }

        const disco = this.torres[deTorre].peek();

        if (this.torres[aTorre].isEmpty() || this.torres[aTorre].peek() > disco) {
            this.torres[aTorre].push(this.torres[deTorre].pop());
            return true;
        } else {
            console.log("No se puede mover el disco a la torre de destino.");
            return false;
        }
    }

    haGanado() {
        const torreDestino = this.torres[2];
        const numDiscos = this.torres[0].size() + this.torres[1].size() + torreDestino.size();

        return (
            torreDestino.size() === numDiscos &&
            torreDestino.items.join(',') === Array.from({ length: numDiscos }, (_, i) => numDiscos - i).join(',')
        );
    }

    mostrarTorres() {
        console.log("\nTorres actuales:");
        this.torres.forEach((torre, index) => {
            console.log(chalk.bold(`Torre ${index + 1}:`));
            if (torre.isEmpty()) {
                console.log(" ".repeat(5) + chalk.gray("Vacia"));
            } else {
                torre.items.forEach(disco => {
                    const color = this.obtenerColor(disco);
                    console.log(color(this.representarDisco(disco)));
                });
            }
        });
        console.log("\n");
    }

    obtenerColor(disco) {
        const colores = [
            chalk.red,
            chalk.green,
            chalk.yellow,
            chalk.blue,
            chalk.magenta,
            chalk.cyan
        ];
        return colores[disco % colores.length];
    }

    representarDisco(disco) {
        const base = '■'.repeat(disco * 2);
        return ' '.repeat(6 - disco) + base + ' '.repeat(6 - disco);
    }
}

module.exports = TorresDeHanoi;

class Pila {
    constructor() {
        this.items = []; // Inicializa un array vacío para almacenar los elementos de la pila
    }

    // Añade un nuevo elemento a la cima de la pila
    push(element) {
        this.items.push(element);
    }

    // Elimina y retorna el elemento de la cima de la pila
    pop() {
        return this.items.pop();
    }

    // Retorna el elemento de la cima de la pila sin eliminarlo
    peek() {
        return this.items[this.items.length - 1];
    }

    // Verifica si la pila está vacía
    isEmpty() {
        return this.items.length === 0;
    }

    // Retorna el número de elementos en la pila
    size() {
        return this.items.length;
    }

    // Vacía todos los elementos de la pila
    clear() {
        this.items = [];
    }
}

class TorresDeHanoi {
    constructor() {
        // Inicializa tres torres, cada una representada por una instancia de la clase Pila
        this.torres = [new Pila(), new Pila(), new Pila()]; 
    }

    // Inicializa la torre 1 con el número de discos especificado
    inicializar(numDiscos) {
        for (let i = numDiscos; i > 0; i--) {
            this.torres[0].push(i); // Apila los discos en la Torre 1, del más grande al más pequeño
        }
    }

    // Realiza el movimiento de un disco desde una torre a otra
    mover(deTorre, aTorre) {
        // Verifica si la torre de origen está vacía
        if (this.torres[deTorre].isEmpty()) {
            console.log("No hay discos en la torre de origen.");
            return false; // Movimiento inválido si la torre de origen está vacía
        }

        const disco = this.torres[deTorre].peek(); // Obtiene el disco superior de la torre de origen

        // Verifica si la torre de destino está vacía o si el disco es más pequeño que el disco en la cima de la torre de destino
        if (this.torres[aTorre].isEmpty() || this.torres[aTorre].peek() > disco) {
            this.torres[aTorre].push(this.torres[deTorre].pop()); // Mueve el disco a la torre de destino
            return true; // Movimiento exitoso
        } else {
            console.log("No se puede mover el disco a la torre de destino.");
            return false; // Movimiento inválido si la torre de destino tiene un disco más pequeño
        }
    }

    // Verifica si el jugador ha ganado el juego
    haGanado() {
        const torreDestino = this.torres[2]; // Torre 3 es la torre de destino
        const numDiscos = this.torres[0].size() + this.torres[1].size() + torreDestino.size(); // Total de discos en todas las torres

        // Verifica si la Torre 3 contiene todos los discos en el orden correcto (del más grande al más pequeño)
        return (
            torreDestino.size() === numDiscos && // Verifica si la Torre 3 contiene todos los discos
            torreDestino.items.join(',') === Array.from({ length: numDiscos }, (_, i) => numDiscos - i).join(',') // Verifica el orden de los discos
        );
    }
}

module.exports = TorresDeHanoi; // Exporta la clase TorresDeHanoi para usarla en otros archivos

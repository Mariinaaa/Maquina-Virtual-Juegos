// Importar módulos y clases
const readline = require('readline'); // Módulo para leer la entrada de la consola
const fs = require('fs'); // Módulo para interactuar con el sistema de archivos
const MaquinaVirtualSimple = require('./MaquinaVirtualSimple'); // Clase de la máquina virtual simple
const TorresDeHanoi = require('./MaquinaVirtualHanoi'); // Clase para el juego Torres de Hanoi

// Crear una interfaz de entrada y salida
const rl = readline.createInterface({
    input: process.stdin, // Definir la entrada del usuario
    output: process.stdout // Definir la salida del texto
});

// Instanciar la máquina virtual y otros elementos
const maquina = new MaquinaVirtualSimple(); // Instancia de la máquina virtual simple
const disparosRealizados = new Set(); // Almacenar las coordenadas de los disparos realizados
const tablero = Array(10).fill(null).map(() => Array(10).fill('~')); // Inicializa el tablero para Hundir la flota con '~'

// Función para mostrar el menú principal
function mostrarMenu() {
    console.log("Elige un juego:"); // Mostrar las opciones del menú
    console.log("1. Torres de Hanoi");
    console.log("2. Hundir la flota");
    console.log("3. Salir");
}

// Función para jugar Torres de Hanoi
function jugarTorresDeHanoi() {
    const juegoHanoi = new TorresDeHanoi(); // Instanciar el juego Torres de Hanoi
    rl.question("¿Cuántos discos quieres usar? ", (numDiscos) => { // Preguntar cuántos discos usar
        juegoHanoi.inicializar(parseInt(numDiscos)); // Inicializar el juego con el número de discos

        // Función para mostrar el estado actual de las torres
        const mostrarEstadoTorres = () => {
            console.log("Estado actual de las torres:");
            console.log(`Torre 1: ${juegoHanoi.torres[0].items.join(' ')}`); // Mostrar los discos en la Torre 1
            console.log(`Torre 2: ${juegoHanoi.torres[1].items.join(' ')}`); // Mostrar los discos en la Torre 2
            console.log(`Torre 3: ${juegoHanoi.torres[2].items.join(' ')}\n`); // Mostrar los discos en la Torre 3
        };

        mostrarEstadoTorres(); // Llamar a la función para mostrar el estado inicial

        // Función para solicitar el movimiento del usuario
        const solicitarMovimiento = () => {
            rl.question("Ingresa el movimiento (deTorre aTorre) o 'exit' para salir: ", (input) => { // Preguntar el movimiento
                if (input.toLowerCase() === 'exit') { // Verificar si el usuario desea salir
                    console.log("Saliendo del juego de Torres de Hanoi.");
                    rl.close(); // Cerrar la interfaz de readline
                    return; // Salir de la función
                }

                const [deTorre, aTorre] = input.split(',').map(Number); // Parsear el movimiento ingresado

                // Verificar si las torres ingresadas son válidas
                if (isNaN(deTorre) || isNaN(aTorre) || deTorre < 1 || deTorre > 3 || aTorre < 1 || aTorre > 3) {
                    console.log("Entrada no válida. Debes ingresar números del 1 al 3.");
                    return solicitarMovimiento(); // Solicitar nuevamente el movimiento
                }

                const movimientoExitoso = juegoHanoi.mover(deTorre - 1, aTorre - 1); // Intentar mover el disco
                if (movimientoExitoso) {
                    console.log(`Moviendo disco de la Torre ${deTorre} a la Torre ${aTorre}.`);
                    mostrarEstadoTorres(); // Mostrar el estado actualizado de las torres
                } else {
                    console.log("Movimiento no permitido."); // Informar de un movimiento no válido
                }

                if (juegoHanoi.haGanado()) { // Verificar si el jugador ha ganado
                    console.log("¡Felicidades, has ganado!");
                    rl.close(); // Cerrar la interfaz de readline
                } else {
                    solicitarMovimiento(); // Solicitar otro movimiento
                }
            });
        };

        solicitarMovimiento(); // Iniciar el ciclo de movimientos
    });
}

// Función para listar archivos .mc en el directorio actual
function listarArchivosMC(callback) {
    fs.readdir('.', (err, archivos) => { // Leer los archivos del directorio actual
        if (err) {
            console.error("Error al leer el directorio:", err); // Mostrar un error si ocurre
            return callback([]); // Retornar un array vacío si hay un error
        }
        const archivosMC = archivos.filter(archivo => archivo.endsWith('.mc')); // Filtrar solo los archivos .mc
        callback(archivosMC); // Retornar los archivos .mc encontrados
    });
}

// Función para iniciar el juego Hundir la flota
function iniciarHundirLaFlota() {
    console.log("Iniciando Hundir la flota..."); // Mensaje inicial del juego

    listarArchivosMC((archivos) => { // Llamar a la función para listar archivos
        if (archivos.length === 0) { // Verificar si no hay archivos .mc
            console.log("No se encontraron archivos .mc. Asegúrate de que haya archivos en el directorio.");
            rl.close(); // Cerrar la interfaz de readline
            return;
        }

        console.log("Selecciona un archivo .mc:");
        archivos.forEach((archivo, index) => { // Listar los archivos disponibles
            console.log(`${index + 1}. ${archivo}`);
        });

        rl.question("Ingresa el número del archivo que deseas cargar: ", (opcion) => { // Preguntar al usuario por el archivo a cargar
            const archivoSeleccionado = archivos[parseInt(opcion) - 1]; // Obtener el archivo seleccionado

            if (!archivoSeleccionado) { // Verificar si la opción ingresada es válida
                console.log("Opción no válida.");
                rl.close(); // Cerrar la interfaz de readline
                return;
            }

            maquina.cargarProgramaDesdeArchivo(archivoSeleccionado); // Cargar el programa desde el archivo .mc

            maquina.ejecutar(); // Ejecutar las instrucciones del programa cargado

            // Función para realizar un disparo en Hundir la flota
            const disparar = () => {
                maquina.imprimirTablero(); // Mostrar el tablero

                rl.question('Ingresa las coordenadas para disparar (x,y) o "exit" para salir: ', (input) => { // Pedir las coordenadas para disparar
                    if (input.toLowerCase() === 'exit') { // Verificar si el usuario desea salir
                        console.log("Saliendo del juego de Hundir la flota.");
                        rl.close(); // Cerrar la interfaz de readline
                        return;
                    }

                    const [x, y] = input.split(',').map(Number); // Parsear las coordenadas

                    // Verificar si las coordenadas están dentro del rango permitido
                    if (x < 0 || x >= 10 || y < 0 || y >= 10) {
                        console.log("Coordenadas fuera del rango. Debes ingresar valores entre 0 y 9.");
                        return disparar(); // Volver a solicitar coordenadas
                    }

                    if (!disparosRealizados.has(`${x},${y}`)) { // Verificar si ya se ha disparado en esas coordenadas
                        disparosRealizados.add(`${x},${y}`); // Agregar las coordenadas a la lista de disparos realizados
                        const resultado = maquina.disparar(x, y); // Realizar el disparo
                        if (resultado) {
                            console.log(`Disparo en (${x}, ${y}) exitoso.`);
                        } else {
                            console.log(`Fallaste en (${x}, ${y}).`);
                        }

                        if (maquina.todosLosBarcosHundidos()) { // Verificar si el jugador ha hundido todos los barcos
                            console.log("¡Has hundido todos los barcos! Fin del juego.");
                            rl.close(); // Cerrar la interfaz de readline
                        } else {
                            disparar(); // Volver a solicitar un disparo
                        }
                    } else {
                        console.log("Ya disparaste en estas coordenadas. Prueba con otras."); // Informar si ya se disparó en esas coordenadas
                        disparar(); // Solicitar nuevas coordenadas
                    }
                });
            };

            disparar(); // Iniciar la secuencia de disparos
        });
    });
}

// Comenzar el juego mostrando el menú inicial
mostrarMenu();
rl.question("Selecciona una opción: ", (opcion) => { // Preguntar al usuario por la opción a elegir
    switch (opcion) {
        case '1':
            jugarTorresDeHanoi(); // Iniciar el juego de Torres de Hanoi
            break;
        case '2':
            iniciarHundirLaFlota(); // Iniciar el juego de Hundir la flota
            break;
        case '3':
            console.log("Gracias por jugar. ¡Hasta la próxima!"); // Mensaje de despedida
            rl.close(); // Cerrar la interfaz de readline
            break;
        default:
            console.log("Opción no válida. Por favor selecciona 1, 2 o 3."); // Mensaje de error si la opción no es válida
            rl.close(); // Cerrar la interfaz de readline
    }
});
